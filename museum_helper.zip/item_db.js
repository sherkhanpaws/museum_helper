var item_db = {
"flowers" : [
{id:"260","name":"Dahlia"},
{id:"264","name":"Orchid"},
{id:"282","name":"African Violet"},
{id:"277","name":"Cherry Blossom"},
{id:"276","name":"Peony"},
{id:"271","name":"Ceibo Flower"},
{id:"272","name":"Edelweiss"},
{id:"263","name":"Crocus"},
{id:"267","name":"Heather"},
{id:"385","name":"Tribulus Omanense"},
{id:"617","name":"Banana Orchid"}
],
"plushies" : [
{id:"258","name":"Jaguar Plushie"},
{id:"281","name":"Lion Plushie"},
{id:"274","name":"Panda Plushie"},
{id:"269","name":"Monkey Plushie"},
{id:"273","name":"Chamois Plushie"},
{id:"261","name":"Wolverine Plushie"},
{id:"266","name":"Nessie Plushie"},
{id:"268","name":"Red Fox Plushie"},
{id:"384","name":"Camel Plushie"},
{id:"215","name":"Kitten Plushie"},
{id:"187","name":"Teddy Bear Plushie"},
{id:"186","name":"Sheep Plushie"},
{id:"618","name":"Stingray Plushie"}
]
}



